package stepDefinations;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.LandingPage;
import pageObjects.OffersPage;
import pageObjects.PageObjectManager;
import utills.TestContextSetup;

public class OffersPageStepDefination {
	public WebDriver driver;
	public String landingPageProductName;
	public String offersPageProductName;
	public PageObjectManager pageObjectManager;

	public TestContextSetup testcontextsetup;

	// Creating the Constructor for driver life;
	public OffersPageStepDefination(TestContextSetup testcontextsetup) {
		this.testcontextsetup = testcontextsetup;
	}

	@Then("^User searched for (.+) shortName in offers page$")
	public void user_searched_for_same_short_name_in_offers_page(String shortName) throws InterruptedException {

		switchToOffersPage();
		Thread.sleep(2000);
		OffersPage offersPage = testcontextsetup.pageObjectManager.getOffersPage();
		offersPage.searchItem(shortName);
		Thread.sleep(2000);
		offersPageProductName = offersPage.getProductName();

	}

	public void switchToOffersPage() {
		LandingPage landingPage = testcontextsetup.pageObjectManager.getLandingPage();
		landingPage.topDeals();
		testcontextsetup.genericUtills.SwitchWindowToChild();

	}

	@Then("Validate the product name in offers page with Landing Page")
	public void Validate_the_product_name_in_offers_page_with_Landing_Page() {
		Assert.assertEquals(testcontextsetup.landingPageProductName, offersPageProductName);

		System.out.println(testcontextsetup.landingPageProductName);
		System.out.println(offersPageProductName);
	}

}
